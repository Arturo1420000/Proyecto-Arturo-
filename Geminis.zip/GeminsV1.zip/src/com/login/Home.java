package com.login;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.MouseEvent;
import javax.swing.JPanel;


public class Home extends javax.swing.JFrame {

   
   int MouseX,MouseY;
    public Home() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PanelPrincipal = new javax.swing.JPanel();
        BarraLateral = new javax.swing.JPanel();
        Button_Mi_Info = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        Button_Almacen = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        Button_Calidad = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        Button_Compras = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        Button_Ventas = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        Button_Produccion = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        Button_info = new javax.swing.JLabel();
        Panel_Exit = new javax.swing.JPanel();
        Button_Exit = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        Button_Home = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        Button_rHmanos = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        Button_Proveedores = new javax.swing.JLabel();
        PanelCompartido = new javax.swing.JPanel();
        panelcomp = new javax.swing.JTabbedPane();
        jPanel10 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        Panel_Min = new javax.swing.JPanel();
        Button_Min = new javax.swing.JLabel();
        Panel_Close = new javax.swing.JPanel();
        Button_Close = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);
        addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                formMouseDragged(evt);
            }
        });
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                formMousePressed(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        PanelPrincipal.setBackground(new java.awt.Color(153, 255, 153));
        PanelPrincipal.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        BarraLateral.setBackground(new java.awt.Color(153, 255, 153));
        BarraLateral.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Button_Mi_Info.setFont(new java.awt.Font("Roboto", 1, 14)); // NOI18N
        Button_Mi_Info.setForeground(new java.awt.Color(255, 255, 255));
        Button_Mi_Info.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Button_Mi_Info.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/usuario48.png"))); // NOI18N
        Button_Mi_Info.setText("Ver mi Información");
        Button_Mi_Info.setToolTipText("");
        Button_Mi_Info.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Button_Mi_Info.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Button_Mi_Info.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BarraLateral.add(Button_Mi_Info, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 210, -1));

        jPanel1.setBackground(new java.awt.Color(153, 255, 153));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Button_Almacen.setBackground(new java.awt.Color(153, 255, 153));
        Button_Almacen.setFont(new java.awt.Font("Roboto", 1, 18)); // NOI18N
        Button_Almacen.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Button_Almacen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/almacen.png"))); // NOI18N
        Button_Almacen.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Button_Almacen.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Button_AlmacenMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Button_AlmacenMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Button_AlmacenMouseExited(evt);
            }
        });
        jPanel1.add(Button_Almacen, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 210, 40));

        BarraLateral.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 210, 40));

        jPanel2.setBackground(new java.awt.Color(153, 255, 153));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Button_Calidad.setBackground(new java.awt.Color(153, 255, 153));
        Button_Calidad.setFont(new java.awt.Font("Roboto", 1, 18)); // NOI18N
        Button_Calidad.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Button_Calidad.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/calidad.png"))); // NOI18N
        Button_Calidad.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Button_Calidad.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Button_CalidadMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Button_CalidadMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Button_CalidadMouseExited(evt);
            }
        });
        jPanel2.add(Button_Calidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 210, 40));

        BarraLateral.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 180, 210, 40));

        jPanel3.setBackground(new java.awt.Color(153, 255, 153));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Button_Compras.setBackground(new java.awt.Color(153, 255, 153));
        Button_Compras.setFont(new java.awt.Font("Roboto", 1, 18)); // NOI18N
        Button_Compras.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Button_Compras.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/compras.png"))); // NOI18N
        Button_Compras.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Button_Compras.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Button_ComprasMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Button_ComprasMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Button_ComprasMouseExited(evt);
            }
        });
        jPanel3.add(Button_Compras, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 210, 40));

        BarraLateral.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 230, 210, 40));

        jPanel4.setBackground(new java.awt.Color(153, 255, 153));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Button_Ventas.setBackground(new java.awt.Color(153, 255, 153));
        Button_Ventas.setFont(new java.awt.Font("Roboto", 1, 18)); // NOI18N
        Button_Ventas.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Button_Ventas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/ventas.png"))); // NOI18N
        Button_Ventas.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Button_Ventas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Button_VentasMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Button_VentasMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Button_VentasMouseExited(evt);
            }
        });
        jPanel4.add(Button_Ventas, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 210, 40));

        BarraLateral.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 280, 210, 40));

        jPanel5.setBackground(new java.awt.Color(153, 255, 153));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Button_Produccion.setBackground(new java.awt.Color(204, 255, 204));
        Button_Produccion.setFont(new java.awt.Font("Roboto", 1, 18)); // NOI18N
        Button_Produccion.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Button_Produccion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/produccion.png"))); // NOI18N
        Button_Produccion.setToolTipText("");
        Button_Produccion.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Button_Produccion.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Button_ProduccionMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Button_ProduccionMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Button_ProduccionMouseExited(evt);
            }
        });
        jPanel5.add(Button_Produccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 210, 40));

        BarraLateral.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 330, 210, 40));

        jPanel6.setBackground(new java.awt.Color(153, 255, 153));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Button_info.setBackground(new java.awt.Color(153, 255, 153));
        Button_info.setFont(new java.awt.Font("Roboto", 1, 18)); // NOI18N
        Button_info.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Button_info.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/información-35.png"))); // NOI18N
        Button_info.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Button_info.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Button_infoMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Button_infoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Button_infoMouseExited(evt);
            }
        });
        jPanel6.add(Button_info, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 210, 40));

        BarraLateral.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 610, 210, 40));

        Panel_Exit.setBackground(new java.awt.Color(102, 0, 0));
        Panel_Exit.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Button_Exit.setFont(new java.awt.Font("Roboto", 1, 18)); // NOI18N
        Button_Exit.setForeground(new java.awt.Color(255, 255, 255));
        Button_Exit.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Button_Exit.setText("Salir");
        Button_Exit.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Button_Exit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Button_ExitMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Button_ExitMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Button_ExitMouseExited(evt);
            }
        });
        Panel_Exit.add(Button_Exit, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 190, 40));

        BarraLateral.add(Panel_Exit, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 670, 190, 40));

        jPanel7.setBackground(new java.awt.Color(153, 255, 153));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Button_Home.setBackground(new java.awt.Color(153, 255, 153));
        Button_Home.setFont(new java.awt.Font("Roboto", 1, 18)); // NOI18N
        Button_Home.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Button_Home.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/windows-35.png"))); // NOI18N
        Button_Home.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Button_Home.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Button_HomeMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Button_HomeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Button_HomeMouseExited(evt);
            }
        });
        jPanel7.add(Button_Home, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 210, 40));

        BarraLateral.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 210, 40));

        jPanel8.setBackground(new java.awt.Color(153, 255, 153));
        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Button_rHmanos.setBackground(new java.awt.Color(204, 255, 204));
        Button_rHmanos.setFont(new java.awt.Font("Roboto", 1, 18)); // NOI18N
        Button_rHmanos.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Button_rHmanos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/recursos.png"))); // NOI18N
        Button_rHmanos.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Button_rHmanos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Button_rHmanosMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Button_rHmanosMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Button_rHmanosMouseExited(evt);
            }
        });
        jPanel8.add(Button_rHmanos, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 210, 40));

        BarraLateral.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 380, 210, 42));

        jPanel9.setBackground(new java.awt.Color(153, 255, 153));
        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Button_Proveedores.setBackground(new java.awt.Color(153, 255, 153));
        Button_Proveedores.setFont(new java.awt.Font("Roboto", 1, 18)); // NOI18N
        Button_Proveedores.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Button_Proveedores.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/provedores.png"))); // NOI18N
        Button_Proveedores.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Button_Proveedores.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Button_ProveedoresMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Button_ProveedoresMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Button_ProveedoresMouseExited(evt);
            }
        });
        jPanel9.add(Button_Proveedores, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 210, 40));

        BarraLateral.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 430, 210, 45));

        PanelPrincipal.add(BarraLateral, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 210, 730));

        PanelCompartido.setBackground(new java.awt.Color(255, 255, 255));

        panelcomp.setBackground(new java.awt.Color(255, 255, 255));
        panelcomp.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        panelcomp.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panelcomp.setFont(new java.awt.Font("Roboto", 1, 12)); // NOI18N
        panelcomp.setMaximumSize(new java.awt.Dimension(1070, 660));

        jPanel10.setBackground(new java.awt.Color(255, 255, 255));
        jPanel10.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/kl.png"))); // NOI18N

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1050, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 609, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout PanelCompartidoLayout = new javax.swing.GroupLayout(PanelCompartido);
        PanelCompartido.setLayout(PanelCompartidoLayout);
        PanelCompartidoLayout.setHorizontalGroup(
            PanelCompartidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelCompartidoLayout.createSequentialGroup()
                .addComponent(panelcomp, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(PanelCompartidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(PanelCompartidoLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        PanelCompartidoLayout.setVerticalGroup(
            PanelCompartidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelCompartidoLayout.createSequentialGroup()
                .addComponent(panelcomp, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(PanelCompartidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(PanelCompartidoLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        PanelPrincipal.add(PanelCompartido, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 80, 1070, 660));

        Panel_Min.setBackground(new java.awt.Color(255, 255, 255));

        Button_Min.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Button_Min.setText("—");
        Button_Min.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Button_Min.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Button_MinMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Button_MinMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Button_MinMouseExited(evt);
            }
        });

        javax.swing.GroupLayout Panel_MinLayout = new javax.swing.GroupLayout(Panel_Min);
        Panel_Min.setLayout(Panel_MinLayout);
        Panel_MinLayout.setHorizontalGroup(
            Panel_MinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Button_Min, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );
        Panel_MinLayout.setVerticalGroup(
            Panel_MinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Button_Min, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        PanelPrincipal.add(Panel_Min, new org.netbeans.lib.awtextra.AbsoluteConstraints(1220, 0, -1, 30));

        Panel_Close.setBackground(new java.awt.Color(255, 255, 255));

        Button_Close.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Button_Close.setText("x");
        Button_Close.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Button_Close.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Button_CloseMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Button_CloseMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Button_CloseMouseExited(evt);
            }
        });

        javax.swing.GroupLayout Panel_CloseLayout = new javax.swing.GroupLayout(Panel_Close);
        Panel_Close.setLayout(Panel_CloseLayout);
        Panel_CloseLayout.setHorizontalGroup(
            Panel_CloseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Button_Close, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );
        Panel_CloseLayout.setVerticalGroup(
            Panel_CloseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Button_Close, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        PanelPrincipal.add(Panel_Close, new org.netbeans.lib.awtextra.AbsoluteConstraints(1250, 0, -1, -1));

        getContentPane().add(PanelPrincipal, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 740));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Button_ExitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_ExitMouseClicked
        if(MouseEvent.BUTTON1 == evt.getButton()){
            System.exit(0);
        }
    }//GEN-LAST:event_Button_ExitMouseClicked
    
    private void Button_AlmacenMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_AlmacenMouseClicked
        // TODO add your handling code here:
        almacen alm = new almacen();
        alm.setSize(1060, 660);
        alm.setLocation(0,0);
        panelcomp.add(alm);
        alm.setVisible(true);
    }//GEN-LAST:event_Button_AlmacenMouseClicked

    private void Button_CalidadMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_CalidadMouseClicked
        // TODO add your handling code here:
        calidad cal = new calidad();
        cal.setSize(1060, 660);
        cal.setLocation(0,0);
        panelcomp.add(cal);
                cal.setVisible(true);
    }//GEN-LAST:event_Button_CalidadMouseClicked

    private void Button_ComprasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_ComprasMouseClicked
        // TODO add your handling code here:
        compras com = new compras();
        com.setSize(1060, 660);
        com.setLocation(0,0);
        panelcomp.add(com);
                com.setVisible(true);
    }//GEN-LAST:event_Button_ComprasMouseClicked

    private void Button_VentasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_VentasMouseClicked
        // TODO add your handling code here:
        v ventas = new v();
        ventas.setSize(1060, 660);
        ventas.setLocation(0,0);
        panelcomp.add(ventas);
        ventas.setVisible(true);
    }//GEN-LAST:event_Button_VentasMouseClicked

    private void Button_ProduccionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_ProduccionMouseClicked
        // TODO add your handling code here:
        produccion prod = new produccion();
        prod.setSize(1060, 660);
        prod.setLocation(0,0);
        panelcomp.add(prod);
        prod.setVisible(true);
    }//GEN-LAST:event_Button_ProduccionMouseClicked

    
    private void Button_infoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_infoMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_Button_infoMouseClicked

    private void Button_AlmacenMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_AlmacenMouseEntered
        jPanel1.setBackground(new Color(204,255,204));
        Button_Almacen.setText("Almacen");
    }//GEN-LAST:event_Button_AlmacenMouseEntered

    private void Button_AlmacenMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_AlmacenMouseExited
        jPanel1.setBackground(new Color(204,255,204));
        Button_Almacen.setText("");
    }//GEN-LAST:event_Button_AlmacenMouseExited

    private void Button_CalidadMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_CalidadMouseEntered
        jPanel2.setBackground(new Color(204,255,204));
        Button_Calidad.setText("Calidad");
    }//GEN-LAST:event_Button_CalidadMouseEntered

    private void Button_CalidadMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_CalidadMouseExited
        jPanel5.setBackground(new Color(153,255,153));
        Button_Calidad.setText("");
    }//GEN-LAST:event_Button_CalidadMouseExited

    private void Button_ComprasMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_ComprasMouseEntered
        jPanel3.setBackground(new Color(204,255,204));
        Button_Compras.setText("Compras");
    }//GEN-LAST:event_Button_ComprasMouseEntered

    private void Button_ComprasMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_ComprasMouseExited
        jPanel5.setBackground(new Color(153,255,153));
        Button_Compras.setText("");
    }//GEN-LAST:event_Button_ComprasMouseExited

    private void Button_VentasMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_VentasMouseEntered
        jPanel4.setBackground(new Color(204,255,204));
        Button_Ventas.setText("Ventas");
    }//GEN-LAST:event_Button_VentasMouseEntered

    private void Button_VentasMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_VentasMouseExited
        jPanel5.setBackground(new Color(153,255,153));
        Button_Ventas.setText("");
    }//GEN-LAST:event_Button_VentasMouseExited

    private void Button_ProduccionMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_ProduccionMouseEntered
        jPanel5.setBackground(new Color(204,255,204));
        Button_Produccion.setText("Produccion");
    }//GEN-LAST:event_Button_ProduccionMouseEntered

    private void Button_ProduccionMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_ProduccionMouseExited
        jPanel5.setBackground(new Color(153,255,153));
        Button_Produccion.setText("");
    }//GEN-LAST:event_Button_ProduccionMouseExited

    private void Button_infoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_infoMouseEntered
        jPanel6.setBackground(new Color(204,255,204));
        Button_info.setText("Información");
    }//GEN-LAST:event_Button_infoMouseEntered

    private void Button_infoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_infoMouseExited
        jPanel6.setBackground(new Color(153,255,153));
        Button_info.setText("");
    }//GEN-LAST:event_Button_infoMouseExited

    private void Button_ExitMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_ExitMouseEntered
        Panel_Exit.setBackground(Color.red);
    }//GEN-LAST:event_Button_ExitMouseEntered

    private void Button_ExitMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_ExitMouseExited
        Panel_Exit.setBackground(new Color(102,0,0));
    }//GEN-LAST:event_Button_ExitMouseExited

    private void formMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMousePressed
        MouseX = evt.getX();
        MouseY = evt.getY();
    }//GEN-LAST:event_formMousePressed

    private void formMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseDragged
        int X = evt.getXOnScreen();
        int Y = evt.getYOnScreen();
        this.setLocation(X-MouseX, Y-MouseY);
    }//GEN-LAST:event_formMouseDragged

    private void Button_MinMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_MinMouseClicked
        if(MouseEvent.BUTTON1 == evt.getButton()){
            this.setState(Home.ICONIFIED);
        }
    }//GEN-LAST:event_Button_MinMouseClicked

    private void Button_CloseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_CloseMouseClicked
        if(MouseEvent.BUTTON1 == evt.getButton()){
            System.exit(0);
        }
    }//GEN-LAST:event_Button_CloseMouseClicked

    private void Button_CloseMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_CloseMouseEntered
        Panel_Close.setBackground(Color.red);
        Button_Close.setForeground(Color.white);
    }//GEN-LAST:event_Button_CloseMouseEntered

    private void Button_MinMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_MinMouseEntered
        Panel_Min.setBackground(Color.lightGray);
        Button_Min.setForeground(Color.white);
    }//GEN-LAST:event_Button_MinMouseEntered

    private void Button_CloseMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_CloseMouseExited
        Panel_Close.setBackground(Color.white);
        Button_Close.setForeground(Color.black);
    }//GEN-LAST:event_Button_CloseMouseExited

    private void Button_MinMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_MinMouseExited
        Panel_Min.setBackground(Color.white);
        Button_Min.setForeground(Color.black);
    }//GEN-LAST:event_Button_MinMouseExited

    private void Button_HomeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_HomeMouseEntered
        jPanel7.setBackground(new Color(204,255,204));
        Button_Home.setText("Inicio");
    }//GEN-LAST:event_Button_HomeMouseEntered

    private void Button_HomeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_HomeMouseExited
        jPanel7.setBackground(new Color(153,255,153));
        Button_Home.setText("");
    }//GEN-LAST:event_Button_HomeMouseExited

    private void Button_rHmanosMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_rHmanosMouseEntered
        jPanel8.setBackground(new Color(204,255,204));
        Button_rHmanos.setText("Recursos Humanos");
    }//GEN-LAST:event_Button_rHmanosMouseEntered

    private void Button_rHmanosMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_rHmanosMouseExited
        jPanel8.setBackground(new Color(153,255,153));
        Button_rHmanos.setText("");
    }//GEN-LAST:event_Button_rHmanosMouseExited

    private void Button_ProveedoresMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_ProveedoresMouseEntered
        jPanel9.setBackground(new Color(204,255,204));
        Button_Proveedores.setText("Proveedores");
    }//GEN-LAST:event_Button_ProveedoresMouseEntered

    private void Button_ProveedoresMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_ProveedoresMouseExited
        jPanel9.setBackground(new Color(153,255,153));
        Button_Proveedores.setText("");
    }//GEN-LAST:event_Button_ProveedoresMouseExited

    private void Button_ProveedoresMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_ProveedoresMouseClicked
        // TODO add your handling code here:
        proveedores prove = new proveedores();
        prove.setSize(1060, 660);
        prove.setLocation(0,0);
        panelcomp.add(prove);
        prove.setVisible(true);
        prove.setVisible(true);
    }//GEN-LAST:event_Button_ProveedoresMouseClicked

    private void Button_rHmanosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_rHmanosMouseClicked
        // TODO add your handling code here:
        recHumanos rh = new recHumanos();
        rh.setSize(1060, 660);
        rh.setLocation(0,0);
        panelcomp.add(rh);
        rh.setVisible(true);
    }//GEN-LAST:event_Button_rHmanosMouseClicked

    private void Button_HomeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button_HomeMouseClicked
        // TODO add your handling code here:
        Login login = new Login();
        login.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_Button_HomeMouseClicked

   
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Home().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel BarraLateral;
    private javax.swing.JLabel Button_Almacen;
    private javax.swing.JLabel Button_Calidad;
    private javax.swing.JLabel Button_Close;
    private javax.swing.JLabel Button_Compras;
    private javax.swing.JLabel Button_Exit;
    private javax.swing.JLabel Button_Home;
    private javax.swing.JLabel Button_Mi_Info;
    private javax.swing.JLabel Button_Min;
    private javax.swing.JLabel Button_Produccion;
    private javax.swing.JLabel Button_Proveedores;
    private javax.swing.JLabel Button_Ventas;
    private javax.swing.JLabel Button_info;
    private javax.swing.JLabel Button_rHmanos;
    private javax.swing.JPanel PanelCompartido;
    private javax.swing.JPanel PanelPrincipal;
    private javax.swing.JPanel Panel_Close;
    private javax.swing.JPanel Panel_Exit;
    private javax.swing.JPanel Panel_Min;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JTabbedPane panelcomp;
    // End of variables declaration//GEN-END:variables
}
