
/*package com.login;

import java.sql.Connection;


//
 //* @author Arturo

public class Conexion {
    private final String base = "usuarios";
     private final String user = "prueba";
      private final String password = "1234";
       private final String url = "jbdc:mysql://localhost:3306/"+ base;
       
public Connection getConexion()
{


/*almacen de  materia pirma qye ve comparas
almacen de mareria orima que ve ventas
almacen ver si esixste existencia para generaara un producto para poder generar la venta,
compaq*/
